package com.reshnu.StringReverse;

public class third {
    //using built in Reverse function

    public static void main(String [] args){
        String str="Reshnu Chandran G B";

        StringBuilder input=new StringBuilder();

        input.append(str);
        input=input.reverse();
    }
}
