package com.reshnu.StringReverse;

public class test {

    public static void main(String [] args){

        String name="Reshnu Chandran G B";
        char[] array=new char[name.length()];
        char[] test =name.toCharArray();
        for(int i=0;i<name.length();i++){
            array[i]=test[name.length()-i-1];
            System.out.print(array[i]);

        }

    }
}
