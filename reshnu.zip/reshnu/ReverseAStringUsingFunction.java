package com.reshnu;

public class ReverseAStringUsingFunction {
    public static void main(String[] args){
        String str="Reshnu";
        for (int i=0;i<str.length();i++){

            System.out.println();
        }
    }
}
