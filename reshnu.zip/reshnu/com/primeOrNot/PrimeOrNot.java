package com.reshnu.com.primeOrNot;
import java.util.Scanner;

public class PrimeOrNot {

    public static void main(String[] args){
        Scanner d=new Scanner(System.in);
        int flag =1;

        System.out.println("Enter a number check whether prime or not");
        int num1=d.nextInt();
        for(int i=2;i<num1/2;i++){



        }

    }
 }
